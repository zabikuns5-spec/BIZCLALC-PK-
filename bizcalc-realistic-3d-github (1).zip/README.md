# BizCalc — GitHub Pages

Realistic 3D-style single-page business calculator website.

## Files
- `index.html` — complete website, CSS and JavaScript
- `assets/bizcalc-brand-render.png` — optional generated brand visual

## GitHub Pages
1. Create a new public GitHub repository, e.g. `bizcalc`.
2. Upload `index.html` and the `assets` folder.
3. Repository → Settings → Pages.
4. Choose **Deploy from a branch** → `main` → `/ (root)` → Save.
5. Open the Pages URL GitHub gives you.

## Before AdSense
Create real standalone pages for Privacy Policy, Terms, Disclaimer and Contact, and connect a real contact/account backend if those functions are advertised as live. Replace the sample calculator data and content with your own original, useful information.
